




(function(w,i,g,z,o){
var a,m;w['WigzoObject']=o;w[o]=w[o]||function(){
(w[o].q=w[o].q||[]).push(arguments)},w[o].l=1*new Date();w[o].h=z;a=i.createElement(g),
m=i.getElementsByTagName(g)[0];a.async=1;a.src=z;m.parentNode.insertBefore(a,m)
})(window,document,'script','//app.wigzo.com/wigzo.compressed.js','wigzo');
wigzo ('configure', 'MtMnJZkvRk2pRkY1-7Vz6g');




